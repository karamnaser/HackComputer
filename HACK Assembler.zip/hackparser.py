class HackParser:
    def __init__(self,file):
        self.file=open(file,"r")
        self.filetxt=self.file.readlines()
        for i in range(0,len(self.filetxt)):
                self.filetxt[i]= self.filetxt[i].strip()
        self.currentinstruction=0
        print(self.filetxt)

    def hasMoreLine(self):
        if(len(self.filetxt)>self.currentinstruction):
            return True
        else:
            self.file.close()
            return False

    def advance(self):
        if(self.hasMoreLine()):
            self.currentinstruction+=1

    def instructionType(self):
        if self.filetxt[self.currentinstruction]:
            if(self.filetxt[self.currentinstruction].find("@")!=-1):
                return "A_instruction"

            elif(self.filetxt[self.currentinstruction][0]=="("):
                return "L_instruction"
            elif (self.filetxt[self.currentinstruction][0]=="/"):
                return
            else:
                return "C_instruction"

    def symbol(self):
        if self.instructionType() == "A_instruction":
            instruction_length = len(self.filetxt[self.currentinstruction].replace(" ",""))
            print(self.filetxt[self.currentinstruction][1:instruction_length])
            return self.filetxt[self.currentinstruction][1:instruction_length]
        elif self.instructionType() == "L_instruction":
            instruction_length=len(self.filetxt[self.currentinstruction])
            return self.filetxt[self.currentinstruction][1:instruction_length-1]

    def dest(self):
       if(self.instructionType()=="C_instruction" and self.filetxt[self.currentinstruction].find("=")!=-1):
           dest = self.filetxt[self.currentinstruction].split("=")[0]
           return dest.replace(" ","")

    def comp(self):
        comp=""
        if (self.instructionType() == "C_instruction" and self.filetxt[self.currentinstruction].find("=") != -1):
           comp = self.filetxt[self.currentinstruction].split("=")[1]
        elif (self.filetxt[self.currentinstruction].find(";") != -1):
            comp = self.filetxt[self.currentinstruction].split(";")[0]
        return comp.split("\n")[0].replace(" ","")

    def jump(self):
        if(self.instructionType() == "C_instruction" and self.filetxt[self.currentinstruction].find(";") != -1):
            jump=self.filetxt[self.currentinstruction].split(";")[1]
            return jump.split("\n")[0].replace(" ","")
