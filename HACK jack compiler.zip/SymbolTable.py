class SymbolTable:
    def __init__(self):
        self.classsymboltable={}
        self.subroutinsymboltable={}
        self.staticindex=0
        self.fieldindex=0
        self.varindex=0
        self.argindex=0
        self.kind_symbols={
            "static":"static",
            "field":"this",
            "arg":"argument",
            "var":"local"
             }

    def startSubroutine(self):
        self.subroutinsymboltable={}
        self.varindex = 0
        self.argindex = 0

    def define(self,name,type,kind):
        if(kind=="static" or kind=="field"):
            if(kind=="static"):
                self.classsymboltable[name]={"name":name,"type":type,"kind":self.kind_symbols[kind],"index":self.staticindex}
                self.staticindex += 1
            else:
                self.classsymboltable[name] = {"name":name, "type":type, "kind":self.kind_symbols[kind],"index":self.fieldindex}
                self.fieldindex += 1
        elif(kind=="var" or kind=="arg"):
            if(kind=="var"):
                self.subroutinsymboltable[name]={"name":name,"type":type,"kind":self.kind_symbols[kind],"index":self.varindex}
                self.varindex += 1
            else:
                self.subroutinsymboltable[name] = {"name":name, "type":type, "kind":self.kind_symbols[kind], "index":self.argindex}
                self.argindex += 1

    def varCount(self,kind):
        if (kind == "static"):
            return self.staticindex
        elif(kind=="field"):
            return self.fieldindex
        elif(kind=="var"):
            return self.varindex
        elif(kind=="arg"):
            return self.argindex

    def kindOf(self,name):
        if(self.classsymboltable.get(name,-1)!=-1):
            return self.classsymboltable[name]["kind"]
        elif(self.subroutinsymboltable.get(name,-1)!=-1):
            return self.subroutinsymboltable[name]["kind"]

    def typeOf(self,name):
        if(self.classsymboltable.get(name,-1)!=-1):
            return self.classsymboltable[name]["type"]
        elif (self.subroutinsymboltable.get(name, -1) != -1):
            return self.subroutinsymboltable[name]["type"]

    def indexOf(self,name):
        if(self.classsymboltable.get(name,-1)!=-1):
            return self.classsymboltable[name]["index"]
        elif(self.subroutinsymboltable.get(name,-1)!=-1):
            return self.subroutinsymboltable[name]["index"]