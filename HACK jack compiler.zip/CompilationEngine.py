from JackTokenizer import *
from VMWriter import *
from SymbolTable import *

class CompilationEngine:
    def __init__(self,input_file,output_file):
        self.jacttokenizer=JackTokenizer(input_file)
        self.vmwriter=VMWriter(output_file)
        self.symboltable=SymbolTable()
        self.currentclassname=""
        self.currentkind=""
        self.currenttype=""
        self.currentname=""
        self.currentsubroutinname=""
        self.currentsubroutinkind = ""
        self.currentsubroutintype = ""
        self.dontpushthat=False
        self.currentindex=0
        self.argumentnumber=0
        self.whilecounter=0
        self.ifcounter=0


    def LLk(self,k,symbol):
        jumps=1
        while(jumps<=k):
            if(self.jacttokenizer.tokens[self.jacttokenizer.postion+jumps]==symbol):
                return True
            jumps+=1
        return False


    def compileExpressionList(self):
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()!=")"):
            self.compileExpression()
            self.argumentnumber+=1
        while (self.jacttokenizer.symbol() == ","):
            self.jacttokenizer.advance()
            self.compileExpression()
            self.argumentnumber += 1

    def compileSubRoutinCall(self):
        classname = ""
        if (self.LLk(1, ".")):
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                classname=self.jacttokenizer.identifier()
                self.jacttokenizer.advance()

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "."):
                self.jacttokenizer.advance()

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                if(self.symboltable.typeOf(classname)):
                    self.vmwriter.writePush(self.symboltable.kindOf(classname), self.symboltable.indexOf(classname))
                    self.currentsubroutinname= self.symboltable.typeOf(classname)+"."+self.jacttokenizer.identifier()
                    self.argumentnumber += 1
                    self.jacttokenizer.advance()
                else:
                    self.currentsubroutinname = classname + "." + self.jacttokenizer.identifier()
                    self.jacttokenizer.advance()

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "("):
                self.jacttokenizer.advance()

            self.compileExpressionList()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
                self.jacttokenizer.advance()
            self.vmwriter.writeCall(self.currentsubroutinname,self.argumentnumber)
            self.argumentnumber=0

        elif(self.LLk(1, "(")):
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                self.currentsubroutinname =self.currentclassname+"."+self.jacttokenizer.identifier()
                self.argumentnumber += 1
                self.jacttokenizer.advance()

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "("):
                self.vmwriter.writePush("pointer", 0)
                self.jacttokenizer.advance()

            self.compileExpressionList()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
                self.jacttokenizer.advance()
            self.vmwriter.writeCall(self.currentsubroutinname, self.argumentnumber)
            self.argumentnumber=0

    def compileArray(self):
        if(self.LLk(1, "[")):
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                self.vmwriter.writePush(self.symboltable.kindOf(self.jacttokenizer.identifier()),self.symboltable.indexOf(self.jacttokenizer.identifier()))
                self.jacttokenizer.advance()

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "["):
                self.jacttokenizer.advance()
            self.compileExpression()
            self.vmwriter.writeArithmetic("add")

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "]"):
                self.jacttokenizer.advance()


    def compileTerm(self):
        if(self.jacttokenizer.hasMoreLine() and self.LLk(1,".")):
            if (self.LLk(3, "(")):
                self.compileSubRoutinCall()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier() and self.LLk(1,"(")):
            self.compileSubRoutinCall()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "~" or self.jacttokenizer.symbol() == "-"):
            localSymbol = self.jacttokenizer.symbol()
            self.jacttokenizer.advance()
            self.compileTerm()
            if(localSymbol=="-"):
                 self.vmwriter.writeArithmetic("neg")
            else:
                 self.vmwriter.writeArithmetic("not")
            return
        if (self.jacttokenizer.hasMoreLine() and self.LLk(1, "[")):
            self.compileArray()
            self.vmwriter.writePop("pointer", 1)
            self.vmwriter.writePush("that", 0)

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.vmwriter.writePush(self.symboltable.kindOf(self.jacttokenizer.identifier()), self.symboltable.indexOf(self.jacttokenizer.identifier()));
            self.jacttokenizer.advance()
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.intVal()):
            self.vmwriter.writePush("constant",self.jacttokenizer.intVal());
            self.jacttokenizer.advance()
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.stringVal()):
            self.vmwriter.writePush("constant",len(self.jacttokenizer.stringVal().replace('"',"")));
            self.vmwriter.writeCall("String.new", 1)
            for i in range(0,len(self.jacttokenizer.stringVal().replace('"',""))):
                self.vmwriter.writePush("constant",ord(self.jacttokenizer.stringVal().replace('"',"")[i]))
                self.vmwriter.writeCall("String.appendChar",2)
            self.jacttokenizer.advance()
            return
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="true" or self.jacttokenizer.keyWord()=="false"
           or self.jacttokenizer.keyWord()=="null" or self.jacttokenizer.keyWord()=="this"):
            if(self.jacttokenizer.keyWord()=="null" or self.jacttokenizer.keyWord()=="false"):
                self.vmwriter.writePush("constant",0)
            elif(self.jacttokenizer.keyWord()=="true"):
                self.vmwriter.writePush("constant",1)
                self.vmwriter.writeArithmetic("neg")
            elif(self.jacttokenizer.keyWord()=="this"):
                self.vmwriter.writePush("pointer", 0)
            self.jacttokenizer.advance()
            return

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "("):
            self.jacttokenizer.advance()
            self.compileExpression()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
                self.jacttokenizer.advance()


    def compileExpression(self):
        self.compileTerm()
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=='+' or '-' or'=' or'>' or'<'or '&' or '/' or '*' or '|' or ';'or')' or ']' or','):
            if(self.jacttokenizer.symbol()==";"):
                return
            elif(self.jacttokenizer.symbol()==")"):
                return
            elif (self.jacttokenizer.symbol() == "]"):
                return
            elif (self.jacttokenizer.symbol() == ","):
                return
            currentsymbol=self.jacttokenizer.symbol()
            self.jacttokenizer.advance()
            self.compileTerm()

            if(currentsymbol=="<"):
                self.vmwriter.writeArithmetic("lt");
            elif(currentsymbol==">"):
                self.vmwriter.writeArithmetic("gt");
            elif (currentsymbol == "&"):
                self.vmwriter.writeArithmetic("and")

            elif (currentsymbol == "="):
                self.vmwriter.writeArithmetic("eq");

            elif (currentsymbol== "+"):
                self.vmwriter.writeArithmetic("add");

            elif (currentsymbol== "-"):
                self.vmwriter.writeArithmetic("sub")

            elif (currentsymbol== "/"):
                self.vmwriter.writeArithmetic("call Math.divide 2");

            elif (currentsymbol == "*"):
                self.vmwriter.writeArithmetic("call Math.multiply 2");

            elif (currentsymbol== "|"):
                self.vmwriter.writeArithmetic("or");





    def compileLet(self):
        isArray =False
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "let"):
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.LLk(1, "[")):
            isArray=True
            self.compileArray()
            self.vmwriter.writePop("temp", 2)

        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currenttype=self.symboltable.typeOf(self.jacttokenizer.identifier())
            self.currentkind=self.symboltable.kindOf(self.jacttokenizer.identifier())
            self.currentindex=self.symboltable.indexOf(self.jacttokenizer.identifier())
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "="):
            self.jacttokenizer.advance()
        self.compileExpression()

        if(isArray==True):
            self.vmwriter.writePush("temp", 2)
            self.vmwriter.writePop("pointer", 1)
            self.vmwriter.writePop("that", 0)
        else:
            self.vmwriter.writePop(self.currentkind, self.currentindex)

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.jacttokenizer.advance()




    def compileDo(self):
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="do"):
            self.jacttokenizer.advance()
        self.compileSubRoutinCall()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.jacttokenizer.advance()
        self.vmwriter.writePop("temp", 0);


    def compileReturn(self):
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="return"):
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.vmwriter.writePush("constant", 0)
            self.vmwriter.writeReturn()
            self.jacttokenizer.advance()

        elif(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() != ";"):
            self.compileExpression()
            self.jacttokenizer.advance()
            self.vmwriter.writeReturn();





    def compileWhile(self):
        whilecountercopy=self.whilecounter
        self.whilecounter+=1
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "while"):
            self.vmwriter.writelable("whileCON"+str(whilecountercopy))
            self.jacttokenizer.advance()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="("):
            self.jacttokenizer.advance()
        self.compileExpression()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
            self.vmwriter.writeArithmetic("not");
            self.jacttokenizer.advance()


        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
            self.vmwriter.writeIf("whileEND" + str(whilecountercopy))
            self.jacttokenizer.advance()


        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            self.compilestatments()
        self.vmwriter.writeGoTo("whileCON"+str(whilecountercopy))

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
            self.jacttokenizer.advance()
        self.vmwriter.writelable("whileEND"+str(whilecountercopy))

    def compileIf(self):
        ifcountercopy=self.ifcounter
        self.ifcounter+=1

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "if"):
            self.jacttokenizer.advance()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="("):
            self.jacttokenizer.advance()
        self.compileExpression()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
            self.jacttokenizer.advance()

        self.vmwriter.writeArithmetic("not")


        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
            self.vmwriter.writeIf("ifFalse" + str(ifcountercopy))
            self.jacttokenizer.advance()


        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            self.compilestatments()
        self.vmwriter.writeGoTo("ifTrue"+str(ifcountercopy))

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
            self.vmwriter.writelable("ifFalse" + str(ifcountercopy))
            self.jacttokenizer.advance()


        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "else"):
            self.jacttokenizer.advance()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
                self.jacttokenizer.advance()

            while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
                self.compilestatments()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
                self.jacttokenizer.advance()
        self.vmwriter.writelable("ifTrue"+str(ifcountercopy))




    def compilestatments(self):
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            if(self.jacttokenizer.keyWord()=="while"):
                self.compileWhile()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "if"):
                self.compileIf()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "let"):
                self.compileLet()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "do"):
                self.compileDo()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "return"):
                self.compileReturn()

    def compileVarDec(self):
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "var"):
            self.currentkind=self.jacttokenizer.keyWord()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or
            self.jacttokenizer.keyWord() == "boolean"):
            self.currenttype=self.jacttokenizer.keyWord()
            self.jacttokenizer.advance()

        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currenttype=self.jacttokenizer.identifier()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currentname=self.jacttokenizer.identifier()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()==";"):
            self.symboltable.define(self.currentname,self.currenttype,self.currentkind)
            self.jacttokenizer.advance()
        elif(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
            self.symboltable.define(self.currentname, self.currenttype, self.currentkind)
            while (self.jacttokenizer.symbol() == ","):
                self.jacttokenizer.advance()
                if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                    self.currentname=self.jacttokenizer.identifier()
                    self.symboltable.define(self.currentname, self.currenttype, self.currentkind)
                    self.jacttokenizer.advance()
            if (self.jacttokenizer.symbol() == ";"):
                self.jacttokenizer.advance()


    def compileParameterList(self):

         if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="int" or self.jacttokenizer.keyWord()=="char"
            or self.jacttokenizer.keyWord()=="boolean"):
             self.currenttype=self.jacttokenizer.keyWord()
             self.jacttokenizer.advance()

         elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
             self.currenttype = self.jacttokenizer.identifier()
             self.jacttokenizer.advance()

         if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
             self.currentname = self.jacttokenizer.identifier()

             self.jacttokenizer.advance()
         self.symboltable.define(self.currentname,self.currenttype,"arg")
         while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
             self.jacttokenizer.advance()

             if (self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or self.jacttokenizer.keyWord() == "boolean"):
                 self.currenttype=self.jacttokenizer.keyWord()
                 self.jacttokenizer.advance()

             elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                 self.currenttype = self.jacttokenizer.identifier()
                 self.jacttokenizer.advance()

             if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                 self.currentname = self.jacttokenizer.identifier()
                 self.jacttokenizer.advance()
             self.symboltable.define(self.currentname, self.currenttype, "arg")

    def compileSubRoutinBody(self):
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            self.compilestatments()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
            self.jacttokenizer.advance()


    def compileSubroutinDec(self):
        self.symboltable.startSubroutine();
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == 'constructor' or self.jacttokenizer.keyWord() == 'function'
            or self.jacttokenizer.keyWord() == 'method'):
            if (self.jacttokenizer.keyWord()== "method"):
                self.symboltable.define("this",self.currentclassname,"arg");

            self.currentsubroutinkind=self.jacttokenizer.keyWord()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or
            self.jacttokenizer.keyWord() == "boolean" or self.jacttokenizer.keyWord()=="void"):
                self.currentsubroutintype=self.jacttokenizer.keyWord()
                self.jacttokenizer.advance()

        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currentsubroutintype=self.jacttokenizer.identifier()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currentsubroutinname=self.currentclassname +"."+self.jacttokenizer.identifier()
            self.jacttokenizer.advance()


        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="("):
            self.jacttokenizer.advance()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="int" or self.jacttokenizer.keyWord()=="char"
             or self.jacttokenizer.keyWord()=="boolean" or self.jacttokenizer.identifier()):

            while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="int" or self.jacttokenizer.keyWord()=="char"
                 or self.jacttokenizer.keyWord()=="boolean" or self.jacttokenizer.identifier()):
                self.compileParameterList()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()==")"):
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
            self.jacttokenizer.advance()

        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "var"):
            self.compileVarDec()
        self.vmwriter.writeFunction(self.currentsubroutinname,self.symboltable.varCount("var"))

        if(self.currentsubroutinkind=="constructor"):
            if(self.symboltable.varCount("field")>0):
                self.vmwriter.writePush("constant",self.symboltable.varCount("field"))
                self.vmwriter.writeCall("Memory.alloc", 1)
                self.vmwriter.writePop("pointer", 0);
        elif(self.currentsubroutinkind=="method"):
            self.vmwriter.writePush("argument", 0)
            self.vmwriter.writePop("pointer",0)
        self.compileSubRoutinBody()

    def compileClassVarDec(self):
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "static" or self.jacttokenizer.keyWord() == "field"):
            self.currentkind = self.jacttokenizer.keyWord()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or
                self.jacttokenizer.keyWord() == "boolean"):
            self.currenttype = self.jacttokenizer.keyWord()
            self.jacttokenizer.advance()

        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currenttype = self.jacttokenizer.identifier()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currentname = self.jacttokenizer.identifier()
            self.symboltable.define(self.currentname, self.currenttype, self.currentkind)
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.jacttokenizer.advance()
            self.symboltable.define(self.currentname, self.currenttype, self.currentkind)
        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
            self.symboltable.define(self.currentname, self.currenttype, self.currentkind)
            while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
                self.jacttokenizer.advance()
                if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                    self.currentname = self.jacttokenizer.identifier()
                    self.jacttokenizer.advance()
                    self.symboltable.define(self.currentname, self.currenttype, self.currentkind)
            if (self.jacttokenizer.symbol() == ";"):
                self.jacttokenizer.advance()


    def compileClass(self):
        if(self.jacttokenizer.keyWord()=="class"):
            self.jacttokenizer.advance()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.currentclassname=self.jacttokenizer.identifier()
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="{"):
            self.jacttokenizer.advance()

        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="static" or self.jacttokenizer.keyWord()=="field"):
            self.compileClassVarDec()

        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == 'constructor' or self.jacttokenizer.keyWord() == 'function'
               or self.jacttokenizer.keyWord()=='method'):
               self.compileSubroutinDec()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="}"):
            self.jacttokenizer.advance()

