import re

class JackTokenizer:

    def __init__(self, file):
        self.file = file
        self.symbols = ['{', '}', '(', ')', '[', ']', '.', ',', ';', '+', '-', '*',
                   '/','&','|', '<', '>', '=','~']
        self.tokens =[]
        self.string=""
        self.qoutescounter=0
        self.skip=True
        for line in file.readlines():
            line_copy=""
            if(line[0:7].find("/*")!=-1 or line[0:7].find("*")!=-1 or line[0:7].find("//")!=-1 or line=="\n"):
                continue
            elif (line.find("/*")!=-1 or line.find("//")!=-1):
                if(line.find("/*")!=-1):
                    line_copy=line[:line.find("/*")]
                elif(line.find("//")!=-1):
                    line_copy = line[:line.find("//")]
                line=line_copy

            for char in line:
                if (char == '"' and self.qoutescounter <= 1):
                    self.skip = False
                    self.qoutescounter += 1
                if (char == '"' and self.qoutescounter == 2):
                    self.skip = True
                if (self.skip != True):
                    char=char+"_"
                    self.string += char.strip()
                    continue
                if (char in self.symbols):
                    char = " " + char + " "
                if (char != " "):
                    self.string += char
                else:
                    self.string += " "
                    self.qoutescounter=0
        self.tokens=self.string.split()
        self.postion=0
    def hasMoreLine(self):
        if (len(self.tokens) > self.postion):
            return True
        else:
            self.file.close()
            return False

    def advance(self):
        if (self.hasMoreLine()):
            self.postion += 1


    def tokenType(self):
        keywords=['class','constructor','function',
                   'method','field','static','var','int' ,
                   'char','boolean','void','true','false',
                    'null','this','let','do','if','else',
                    'while','return']


        stringpattern="^\"[^\"]+\"$"

        identefyer="^[^\\d\\W]\\w*\\Z"

        if (self.tokens[self.postion] in keywords):
            return "KEYWORD"

        if (self.tokens[self.postion] in self.symbols):
            return "SYMBOl"

        if(self.tokens[self.postion].isdigit()):
            return "INT_CONST"
        if(bool(re.match(stringpattern,self.tokens[self.postion]))):
            return "STRING_CONST"

        if (bool(re.match(identefyer,self.tokens[self.postion]))):
            return "IDENTIFIER_CONST"



    def keyWord(self):
        if(self.tokenType()=="KEYWORD"):
            return self.tokens[self.postion]

    def symbol(self):
        if(self.tokenType()=="SYMBOl"):
            return self.tokens[self.postion]

    def identifier(self):
        if(self.tokenType()=="IDENTIFIER_CONST"):
            return self.tokens[self.postion]

    def intVal(self):
        if(self.tokenType()=="INT_CONST"):
            return self.tokens[self.postion]

    def stringVal(self):
        if(self.tokenType()=="STRING_CONST"):
            return self.tokens[self.postion].replace("_"," ")