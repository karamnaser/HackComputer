class HackVmCodeWriter:
    def __init__(self,outputfile):
        self.outputfile=outputfile
        self.counter=0
    def getsegment(self,segment,arg2):
        segment_symbol={
            "local":"LCL",
            "argument":"ARG",
            "this":"THIS",
            "that":"THAT",
            "constant":"constant",
            "temp":"5",
            "static":"static"
        }
        if(arg2==0):
            segment_symbol["pointer"]=segment_symbol["this"]
        else:
            segment_symbol["pointer"] = segment_symbol["that"]
        return segment_symbol[segment]



    def generateArithmeticComand(self,command):
        return """
        @SP
        M=M-1
        A=M
        D=M
        @SP
        M=M-1
        A=M
        {arthmetic_command}
        @SP
        M=M+1""".format(arthmetic_command=command).replace(" ",'')

    def generateNotCommand(self):
        return """
        @SP
        M=M-1
        A=M
        M=!M
        @SP
        M=M+1""".replace(" ",'')


    def generateNegCommand(self):
        return """
        @SP
        M=M-1
        A=M
        D=M
        @0
        D=A-D
        @SP
        A=M
        M=D
        @SP
        M=M+1""".replace(" ",'')

    def generateLogicComand(self,comand):
        return """
        @SP
        M=M-1
        A=M
        D=M
        @SP
        M=M-1
        A=M
        D=M-D
        @{logic_comand}_true+{counter}
        D;J{logic_comand}
        @{logic_comand}_false+{counter}
        0;JMP
        ({logic_comand}_true+{counter})
        @0
        D=A
        @SP
        A=M
        M=!D
        @SP
        M=M+1
        @SKIP+{counter}
        0;JMP
        ({logic_comand}_false+{counter})
        @0
        D=A
        @SP
        A=M
        M=D
        @SP
        M=M+1
        (SKIP+{counter})
        """.format(logic_comand=comand,counter=self.counter).replace(" ",'')

    def writeArithmetic(self,command):
        if(command):
            if(command=="add"):
                self.outputfile.write(self.generateArithmeticComand("M=D+M"))
            elif(command=="sub"):
               self.outputfile.write(self.generateArithmeticComand("M=M-D"))
            elif (command == "and"):
                self.outputfile.write(self.generateArithmeticComand("M=D&M"))
            elif (command == "or"):
                self.outputfile.write(self.generateArithmeticComand("M=D|M"))
            elif (command == "not"):
                self.outputfile.write(self.generateNotCommand())
            elif (command == "neg"):
                self.outputfile.write(self.generateNegCommand())
            elif (command == "eq"):
                self.outputfile.write(self.generateLogicComand("EQ"))
                self.counter+=1
            elif (command == "lt"):
                self.outputfile.write(self.generateLogicComand("LT"))
                self.counter += 1
            elif (command == "gt"):
                self.outputfile.write(self.generateLogicComand("GT"))
                self.counter += 1



    def generatePopComand(self,segment,index,address):
        if(segment!="constant"):
            return """
            @{index}
            D=A
            @{seqment}
            {segmentaddress}
            D=A+D
            @R13
            M=D
            @SP
            M=M-1
            A=M
            D=M
            @R13
            A=M
            M=D
            """.format(seqment=segment,index=index,segmentaddress=address).replace(" ",'')

    def generatePushComand(self,segment,index,addres):
        if(segment):
            if (segment != "constant"):
                return """
                       @{index}
                       D=A
                       @{seqment}
                       {getsegaddres}
                       D=A+D
                       @R13
                       M=D
                       A=M
                       D=M
                       @SP
                       A=M
                       M=D
                       @SP
                       M=M+1
                       """.format(seqment=segment, index=index,getsegaddres=addres).replace(" ",'')
            else:
              return """
                @{index}
                D=A
                @SP
                A=M
                M=D
                @SP
                M=M+1
                """.format(index=index).replace(" ",'')

    def writePushPop(self,comand,segment_symbol,index):
        print(segment_symbol)
        if(comand=="C_PUSH"):
            address=""
            segment=self.getsegment(segment_symbol,index)
            if (segment_symbol != "temp"):
                address="A=M"
            if(segment_symbol=="pointer"):
                address=""
                index=0
            self.outputfile.write(self.generatePushComand(segment,index,address))

        elif(comand=="C_POP"):
            address = ""
            segment = self.getsegment(segment_symbol,index)
            if (segment_symbol != "temp"):
                address = "A=M"
            if (segment_symbol == "pointer"):
                address = ""
                index = 0
            self.outputfile.write(self.generatePopComand(segment,index,address))

    def close(self):
        self.outputfile.close