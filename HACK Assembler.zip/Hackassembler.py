from hacksymboltable import *
from hackparser import *
from hackcode import *
import sys
import os.path


def findfilepath():
    if (sys.argv[1].find("\\")):
        sys.argv[1] = sys.argv[1].split("\\")[-1]

    for r, d, f in os.walk("C:\\"):
        for files in f:
            if files.capitalize() == sys.argv[1].capitalize():
                return os.path.join(r, files)


hackparser = HackParser(findfilepath())
hackcodegenertor = HackCode()
hacksymboltable = HackSymbolTable()


def firstPass():
    counter = -1
    while (hackparser.hasMoreLine()):
        instructiontype = hackparser.instructionType()
        if (instructiontype == "L_instruction"):
            symbol = hackparser.symbol()
            hacksymboltable.addEntry(symbol, counter + 1)
        elif (instructiontype != None):
            counter += 1
        hackparser.advance()
    hackparser.currentinstruction = 0
    for i in range(0, 16):
        hacksymboltable.addEntry("R" + str(i), i)
    hacksymboltable.addEntry("SCREEN", 16384)
    hacksymboltable.addEntry("KBD", 16384)
    hacksymboltable.addEntry("SP", 0)
    hacksymboltable.addEntry("LCL", 1)
    hacksymboltable.addEntry("ARG", 2)
    hacksymboltable.addEntry("THIS", 3)
    hacksymboltable.addEntry("THAT", 4)


def generateAcode():
    instructiontype = hackparser.instructionType()
    if (instructiontype == "A_instruction"):
        symbol = hackparser.symbol().replace(" ", "")
        if str.isdigit(symbol):
            return str('{0:016b}'.format(int(symbol)))
        elif hacksymboltable.contain(symbol):
            symbol_addres = hacksymboltable.getAddress(symbol)
            return str('{0:016b}'.format(int(symbol_addres)))

        else:
            hacksymboltable.addEntry(symbol, hacksymboltable.symbol_addres_counter)
            hacksymboltable.symbol_addres_counter += 1
            symbol_addres = hacksymboltable.getAddress(symbol)
            return str('{0:016b}'.format(int(symbol_addres)))


def generateCcode():
    instructiontype = hackparser.instructionType()
    last_3_bit = ""
    bit_12 = ""
    last_11_bit = ""
    if (instructiontype == "C_instruction"):
        last_3_bit = "111"
        comp = hackparser.comp()
        dest = hackparser.dest()
        jump = hackparser.jump()
        if (comp.find("M") != -1):
            bit_12 = "1"
        else:
            bit_12 = "0"

        last_11_bit = hackcodegenertor.comp(comp) + hackcodegenertor.dest(dest) + hackcodegenertor.jump(jump)
        return last_3_bit + bit_12 + last_11_bit


def secoundPass():
    filefullname = findfilepath().split(".")[0] + ".hack"
    hackfile = open(filefullname, "w")
    while (hackparser.hasMoreLine()):
        if (generateAcode()):
            hackfile.write(generateAcode() + "\n")
        elif (generateCcode()):
            hackfile.write(generateCcode() + "\n")
        hackparser.advance()
    hackfile.close()


firstPass()
secoundPass()




