import os.path
import sys
class HackVmCodeWriter:
    def __init__(self,outputfile):
        self.outputfile=outputfile
        self.filename=sys.argv[1].split(".")[0]
        self.counter=0
        self.returnaddres_counter=0


    def setFileName(self,fn):
        self.filename=fn

    def writeBootsrapCode(self):
        self.outputfile.write("""
               @256
               D=A
               @SP
               M=D
               """.replace(" ", '')+"\n")
        self.writeCall("Sys.init",0)

    def getsegment(self,segment,arg2):
        segment_symbol={
            "local":"LCL",
            "argument":"ARG",
            "this":"THIS",
            "that":"THAT",
            "constant":"constant",
            "temp":"5",
            "static":"static"
        }
        if(arg2==0):
            segment_symbol["pointer"]=segment_symbol["this"]
        elif(arg2==1):
            segment_symbol["pointer"] = segment_symbol["that"]
        return segment_symbol[segment]



    def generateArithmeticComand(self,command):
        return """
        @SP
        M=M-1
        A=M
        D=M
        @SP
        M=M-1
        A=M
        {arthmetic_command}
        @SP
        M=M+1""".format(arthmetic_command=command).replace(" ",'')

    def generateNotCommand(self):
        return """
        @SP
        M=M-1
        A=M
        M=!M
        @SP
        M=M+1""".replace(" ",'')


    def generateNegCommand(self):
        return """
        @SP
        M=M-1
        A=M
        D=M
        @0
        D=A-D
        @SP
        A=M
        M=D
        @SP
        M=M+1""".replace(" ",'')

    def generateLogicComand(self,comand):
        return """
        @SP
        M=M-1
        A=M
        D=M
        @SP
        M=M-1
        A=M
        D=M-D
        @{logic_comand}_true+{counter}
        D;J{logic_comand}
        @{logic_comand}_false+{counter}
        0;JMP
        ({logic_comand}_true+{counter})
        @0
        D=A
        @SP
        A=M
        M=!D
        @SP
        M=M+1
        @SKIP+{counter}
        0;JMP
        ({logic_comand}_false+{counter})
        @0
        D=A
        @SP
        A=M
        M=D
        @SP
        M=M+1
        (SKIP+{counter})
        """.format(logic_comand=comand,counter=self.counter).replace(" ",'')

    def writeArithmetic(self,command):
        if(command):
            if(command=="add"):
                self.outputfile.write(self.generateArithmeticComand("M=D+M"))
            elif(command=="sub"):
               self.outputfile.write(self.generateArithmeticComand("M=M-D"))
            elif (command == "and"):
                self.outputfile.write(self.generateArithmeticComand("M=D&M"))
            elif (command == "or"):
                self.outputfile.write(self.generateArithmeticComand("M=D|M"))
            elif (command == "not"):
                self.outputfile.write(self.generateNotCommand())
            elif (command == "neg"):
                self.outputfile.write(self.generateNegCommand())
            elif (command == "eq"):
                self.outputfile.write(self.generateLogicComand("EQ"))
                self.counter+=1
            elif (command == "lt"):
                self.outputfile.write(self.generateLogicComand("LT"))
                self.counter += 1
            elif (command == "gt"):
                self.outputfile.write(self.generateLogicComand("GT"))
                self.counter += 1



    def generatePopComand(self,segment,index,address,comand):
        if(segment!="constant"):
            return """
           {comand}
            @{seqment}
            {segmentaddress}
            @R13
            M=D
            @SP
            M=M-1
            A=M
            D=M
            @R13
            A=M
            M=D
            """.format(comand=comand,seqment=segment,index=index,segmentaddress=address).replace(" ",'')

    def generatePushComand(self,segment,index,addres,comand):
        if(segment):
            if (segment != "constant"):
                return """
                      {comand}
                       @{segment}
                       {getadresscomand}
                       @R13
                       M=D
                       A=M
                       D=M
                       @SP
                       A=M
                       M=D
                       @SP
                       M=M+1
                       """.format(comand=comand,segment=segment, index=index,getadresscomand=addres).replace(" ",'')
            else:
              return """
                @{index}
                D=A
                @SP
                A=M
                M=D
                @SP
                M=M+1
                """.format(index=index).replace(" ",'')

    def writePushPop(self,comand,segment_symbol,index):
        print(segment_symbol)
        if(comand=="C_PUSH"):
            address="""A=M
                       D=A+D
                    """
            comand="""@{index}
                      D=A
                    """.format(index=index)
            segment=self.getsegment(segment_symbol,index)
            if (segment_symbol == "temp"):
                address="D=A+D"
            if(segment_symbol=="pointer"):
                comand = ""
                address = "D=A"
            if (segment=="static"):
                segment = self.filename.split(".")[0] + "." + str(index)
                comand=""
                address="D=A"
            self.outputfile.write(self.generatePushComand(segment,index,address,comand))

        elif(comand=="C_POP"):
            segment = self.getsegment(segment_symbol,index)
            address = """A=M
                         D=A+D
                      """
            comand = """@{index}
                        D=A""".format(index=index)
            if (segment_symbol == "temp"):
                address = "D=A+D"
            if (segment_symbol == "pointer"):
                address="D=A"
                comand=""
            if (segment == "static"):
                segment = self.filename.split(".")[0] + "." + str(index)
                comand=""
                address = "D=A"
            self.outputfile.write(self.generatePopComand(segment,index,address,comand))

    def writelable(self,lable):
        self.outputfile.write("("+self.filename+"$"+lable+")")

    def writeGoTo(self,lable):
        lablename = self.filename + "$" + lable
        self.outputfile.write( """
        @{lablename}
        0;JMP
        """.format(lablename=lablename).replace(' ',''))

    def writeIF(self,lable):
        lablename = self.filename + "$" + lable
        self.outputfile.write("""
        @SP
        M=M-1
        A=M
        D=M
        @0
        D=D-A
        @{lablename}
        D;JNE
        """.format(lablename=lablename).replace(' ',''))

    def writePushReturnAdressComand(self):
        return """
        @RETURN_{counter}
        D=A
        @SP
        A=M
        M=D
        @SP
        M=M+1
        """.format(counter=self.returnaddres_counter).replace(" ",'')

    def writePushSegmentAdressComand(self,segment):
        return """
        @{segment}
        D=M
        @SP
        A=M
        M=D
        @SP
        M=M+1
        """.format(segment=segment).replace(" ",'')
    def repostionArgComand(self,narg):
        return  """@SP
        D=M
        @{numArgs}
        D=D-A
        @5
        D=D-A
        @ARG
        M=D
        """.format(numArgs=narg).replace(" ","")

    def repostionLCLComand(self):
       return """
        @SP
        D=M
        @LCL
        M=D 
        """.replace(" ","")

    def writeCall(self,fn,nargs):
        self.outputfile.write(self.writePushReturnAdressComand()+"\n")
        self.outputfile.write(self.writePushSegmentAdressComand("LCL")+"\n")
        self.outputfile.write(self.writePushSegmentAdressComand("ARG")+"\n")
        self.outputfile.write(self.writePushSegmentAdressComand("THIS")+"\n")
        self.outputfile.write(self.writePushSegmentAdressComand("THAT")+"\n")
        self.outputfile.write(self.repostionArgComand(nargs)+"\n")
        self.outputfile.write(self.repostionLCLComand()+"\n")
        self.outputfile.write("""@{functionname}
                                 0;JMP""".format(functionname=fn).replace(" ","")+"\n")
        self.outputfile.write("""(RETURN_{counter})""".format(counter=self.returnaddres_counter).replace(" ","")+"\n")
        self.returnaddres_counter += 1

    def recycle(self,segment,offset):
        self.outputfile.write("""
        @{offset}
        D=A
        @FRAM
        A=M-D
        D=M
        @{segment}
        M=D
        """.format(segment=segment,offset=offset).replace(" ",""))

    def writereturn(self):
       self.outputfile.write("""
        @LCL
        D=M
        @FRAM
        M=D
        @5
        A=D-A
        D=M
        @RET
        M=D
        """.replace(" ",""))
       self.writePushPop("C_POP","argument",0)
       self.outputfile.write("""@ARG
                                D=M+1
                                @SP
                                M=D
                                """.replace(" ",""))
       self.recycle("THAT", 1);
       self.recycle("THIS", 2);
       self.recycle("ARG", 3);
       self.recycle("LCL", 4);
       self.outputfile.write("""
                            @RET
                            A=M
                            0;JMP
                                """.replace(" ",""))



    def writeFunction(self,fn,nargs):
        self.outputfile.write("""({functionname})""".format(functionname=fn).replace(" ",""))
        for i in range(0,int(nargs)):
            self.writePushPop("C_PUSH","constant",0)


    def close(self):
        self.outputfile.close