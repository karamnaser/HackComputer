import sys
import os.path
from os import path
from hackvmparser import *
from hackvmcodewriter import *

def findfilepath():
    if (sys.argv[1].find("\\")):
        print(sys.argv[1])
        print(sys.argv[1].split("\\"))
        sys.argv[1] = sys.argv[1].split("\\")[-1]

    for r, d, f in os.walk("C:\\"):
        for files in f:
            if files.capitalize() == sys.argv[1].capitalize():
                return os.path.join(r, files)

filename=findfilepath()
readble_vm_file=open(filename,"r")
writable_asm_file=open(filename.replace(".vm",".asm"),"w+")
vmparser=HackVmParser(readble_vm_file)
vmcodewriter=HackVmCodeWriter(writable_asm_file)


def main():
    while(vmparser.hasMoreLine()):
        comand_type=vmparser.commandType()
        arg=vmparser.arg1()
        arg2=vmparser.arg2()
        if(comand_type=="C_ARTHRIMETRIC"):
            vmcodewriter.writeArithmetic(arg)
        vmcodewriter.writePushPop(comand_type,arg,arg2)
        vmparser.advance()
    else:
        readble_vm_file.close()
        vmcodewriter.close()


main()



