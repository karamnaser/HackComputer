from CompilationEngine import *
import sys
import os.path

def findfilepath():
    filepath = ""
    
    if(len(sys.argv)>1):
        for value in sys.argv[1:]:
            filepath+=value
        return filepath.replace("'", "") 
    
    if (os.path.isabs(sys.argv[1]) != True and sys.argv[1].find("\\") != -1):
        filepath = os.path.abspath(sys.argv[1])
        return filepath

    elif (os.path.isabs(sys.argv[1]) == True):
        filepath = sys.argv[1]
        return filepath
    else:
        filepath=os.getcwd()

    for r, d, f in os.walk(filepath):
        for files in f:
            if files.capitalize() == sys.argv[1].capitalize():
                return os.path.join(r, files)


def getDirName():
    filepath = ""

    if(len(sys.argv)>1):
        for value in sys.argv[1:]:
            filepath+=value
        return filepath.replace("'", "")

    if (sys.argv[1].find("C:\\")==-1 and sys.argv[1].find("\\") != -1):
        filepath = os.path.abspath(sys.argv[1])
        return filepath

    elif (os.path.isabs(sys.argv[1]) == True):
        filepath = sys.argv[1]
        return filepath

    else:
        filepath=os.getcwd()

    for r, d, f in os.walk(filepath):
        for directory in d:
            if (directory.capitalize() == sys.argv[1].capitalize()):
                dir = os.path.join(r, directory)
                return dir
        else:
            continue


def checkIfFileOrDir():
    if (sys.argv[1].find(".jack") == -1):
        path = (getDirName(), "isdire")
    else:
        path = (findfilepath(), "isfile")
    return path



def main():
    filename = checkIfFileOrDir()
    print(filename)
    fileslist=[]
    if (filename[1] == "isdire"):
        for r, d, f in os.walk(filename[0]):
            fileslist = f
        for file in fileslist:
            if (file.find(".jack") != -1):
                vm_file = open(os.path.join(filename[0] , file.split(".")[0]+"_XML"+".xml"), "w+")
                jack_file = open(os.path.join(filename[0], file), "r")
                compilationengin=CompilationEngine(jack_file,vm_file)
                compilationengin.compileClass()
                jack_file.close()
                vm_file.close()
    else:
        jack_file = open(filename[0], "r")
        vm_path = filename[0].split(".")[0]+"_XML"+ ".xml"
        vm_file = open(vm_path, "w+")
        compilationengin = CompilationEngine(jack_file, vm_file)
        compilationengin.compileClass()
        jack_file.close()
        vm_file.close()

main()