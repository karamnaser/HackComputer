class VMWriter:
    def __init__(self,output_file):
        self.outputfile=output_file

    def writePush(self,sigment,index):
        self.outputfile.write("push {sigment} {index}".format(sigment=sigment,index=index)+"\n")

    def writePop(self,sigment,index):
        if(sigment!="const"):
            self.outputfile.write("pop {sigment} {index}".format(sigment=sigment,index=index)+"\n")

    def writeArithmetic(self,command):
        self.outputfile.write(command+"\n")

    def writelable(self,label):
        self.outputfile.write("label "+str(label)+"\n")

    def writeGoTo(self,label):
        self.outputfile.write("goto "+str(label)+"\n")

    def writeIf(self,label):
        self.outputfile.write("if-goto "+str(label)+"\n")

    def writeCall(self,name,narga):
        self.outputfile.write("call "+str(name)+" "+str(narga)+"\n")

    def writeFunction(self,name,nlocal):
        self.outputfile.write("function "+str(name)+" "+str(nlocal)+"\n")

    def writeReturn(self):
        self.outputfile.write("return"+"\n")

    def close(self):
        self.outputfile.close()



