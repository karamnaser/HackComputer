from JackTokenizer import *

class CompilationEngine:
    def __init__(self,input_file,output_file):
        self.jacttokenizer=JackTokenizer(input_file)
        self.output_file=output_file

    def LLk(self,k,symbol):
        jumps=1
        while(jumps<=k):
            if(self.jacttokenizer.tokens[self.jacttokenizer.postion+jumps]==symbol):
                return True
            jumps+=1
        return False


    def compileExpressionList(self):
        self.output_file.write("       "+"<expressionList>"+"\n")
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()!=")"):
            self.compileExpression()
        while (self.jacttokenizer.symbol() == ","):
            self.output_file.write("        "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
            self.compileExpression()
        self.output_file.write("       "+"</expressionList>"+"\n")

    def compileSubRoutinCall(self):
        if (self.LLk(1, ".")):
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                self.output_file.write("       "+"<identifier>" + str(self.jacttokenizer.identifier() + "</identifier>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "."):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return

            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                self.output_file.write("       "+"<identifier>" + str(self.jacttokenizer.identifier() + "</identifier>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "("):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            self.compileExpressionList()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
        elif(self.LLk(1, "(")):
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                self.output_file.write("       "+"<identifier>" + str(self.jacttokenizer.identifier() + "</identifier>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "("):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            self.compileExpressionList()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return


    def compileArray(self):
        if(self.LLk(1, "[")):
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                self.output_file.write("       "+"<identifier>" + str(self.jacttokenizer.identifier() + "</identifier>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "["):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
            self.compileExpression()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "]"):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return

    def compileTerm(self):
        self.output_file.write("      "+"<term>"+"\n")
        if(self.jacttokenizer.hasMoreLine() and self.LLk(1,".")):
            if (self.LLk(3, "(")):
                self.compileSubRoutinCall()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier() and self.LLk(1,"(")):
            self.compileSubRoutinCall()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "~" or self.jacttokenizer.symbol() == "-"):
            self.output_file.write("       " + "<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>") + "\n")
            self.jacttokenizer.advance()
            self.output_file.write(" ")
            self.compileTerm()
            self.output_file.write("      " + "</term>" + "\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.LLk(1, "[")):
            self.compileArray()

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write("       "+"<identifier>" + str(self.jacttokenizer.identifier() + "</identifier>")+"\n")
            self.jacttokenizer.advance()
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.intVal()):
            self.output_file.write("       "+"<integerConstant>"+str(self.jacttokenizer.intVal())+"</integerConstant>"+"\n")
            self.jacttokenizer.advance()
            self.output_file.write("      " + "</term>" + "\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.stringVal()):
            self.output_file.write("       "+"<stringConstant>" + str(self.jacttokenizer.stringVal().replace('"',"")) + "</stringConstant>"+"\n")
            self.jacttokenizer.advance()
            self.output_file.write("      " + "</term>" + "\n")
            return
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="true" or self.jacttokenizer.keyWord()=="false"
           or self.jacttokenizer.keyWord()=="null" or self.jacttokenizer.keyWord()=="this"):
            self.output_file.write("       "+"<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>")+"\n")
            self.jacttokenizer.advance()
            self.output_file.write("      " + "</term>" + "\n")
            return

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "("):
            self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
            self.compileExpression()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
                self.output_file.write("       "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("       "+"syntax error"+"\n")
                return
        self.output_file.write("      "+"</term>"+"\n")

    def compileExpression(self):
        self.output_file.write("     "+"<expression>"+"\n")
        self.compileTerm()
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=='+' or '-' or'=' or'>' or'<'or '&' or '/' or '*' or '|' or ';'or')' or ']' or','):
            if(self.jacttokenizer.symbol()==";"):
                self.output_file.write("     "+"</expression>"+"\n")
                return
            elif(self.jacttokenizer.symbol()==")"):
                self.output_file.write("     "+"</expression>"+"\n")
                return
            elif (self.jacttokenizer.symbol() == "]"):
                self.output_file.write("     " + "</expression>" + "\n")
                return
            elif (self.jacttokenizer.symbol() == ","):
                self.output_file.write("     "+"</expression>"+"\n")
                return
            else:
                if(self.jacttokenizer.symbol()=="<"):
                    self.output_file.write("      " + "<symbol>" +"&lt;"+ "</symbol>" + "\n")
                    self.jacttokenizer.advance()
                elif(self.jacttokenizer.symbol()==">"):
                    self.output_file.write( "      " + "<symbol>" + "&gt;" + "</symbol>" + "\n")
                    self.jacttokenizer.advance()
                elif (self.jacttokenizer.symbol() == "&"):
                    self.output_file.write("      " + "<symbol>" + "&amp;" + "</symbol>" + "\n")
                    self.jacttokenizer.advance()
                else:
                    self.output_file.write("      "+"<symbol>" + str(self.jacttokenizer.symbol()) + "</symbol>"+"\n")
                    self.jacttokenizer.advance()
                self.compileTerm()
        self.output_file.write("     "+"</expression>"+"\n")




    def compileLet(self):
        self.output_file.write("    "+"<letStatement>"+"\n")

        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "let"):
            self.output_file.write("     "+"<keyword>"+str(self.jacttokenizer.keyWord()+"</keyword>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.LLk(1, "[")):
            self.compileArray()
        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write("     "+"<identifier>" + str(self.jacttokenizer.identifier()+ "</identifier>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "="):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol()+ "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.compileExpression()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol()+ "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.output_file.write("    "+"</letStatement>"+"\n")

    def compileDo(self):
        self.output_file.write("    "+"<doStatement>"+"\n")
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="do"):
            self.output_file.write("     "+"<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.compileSubRoutinCall()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol()+ "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.output_file.write("    "+"</doStatement>"+"\n")

    def compileReturn(self):
        self.output_file.write("    "+"<returnStatement>"+"\n")
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="return"):
            self.output_file.write("     "+"<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() != ";"):
            self.compileExpression()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol()+ "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.output_file.write("    "+"</returnStatement>"+"\n")


    def compileWhile(self):
        self.output_file.write("    "+"<whileStatement>"+"\n")
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "while"):
            self.output_file.write("     "+"<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="("):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.compileExpression()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return

        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            self.compilestatments()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.output_file.write("    "+"</whileStatement>"+"\n")

    def compileIf(self):
        self.output_file.write("    "+"<ifStatement>"+"\n")
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "if"):
            self.output_file.write("     "+"<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="("):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        self.compileExpression()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ")"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
            self.output_file.write("<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            self.compilestatments()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
            self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("     "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "else"):
            self.output_file.write("     "+"<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>")+"\n")
            self.jacttokenizer.advance()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "{"):
                self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+'\n')
                self.jacttokenizer.advance()
            else:
                self.output_file.write("     "+"syntax error"+"\n")
                return
            while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
                self.compilestatments()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
                self.output_file.write("     "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
            else:
                self.output_file.write("     "+"syntax error"+"\n")
                return
        self.output_file.write("    "+"</ifStatement>"+"\n")



    def compilestatments(self):
        self.output_file.write("   "+"<statements>"+"\n")
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            if(self.jacttokenizer.keyWord()=="while"):
                self.compileWhile()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "if"):
                self.compileIf()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "let"):
                self.compileLet()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "do"):
                self.compileDo()
            if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "return"):
                self.compileReturn()
        self.output_file.write("   "+"</statements>"+"\n")

    def compileVarDec(self):
        self.output_file.write(" "+"<varDec>"+"\n")
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "var"):
            self.output_file.write("  "+"<keyword>" + str(self.jacttokenizer.keyWord()) + "</keyword>"+"\n")
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or
            self.jacttokenizer.keyWord() == "boolean"):
            self.output_file.write("  "+"<keyword>" + str(self.jacttokenizer.keyWord()) + "</keyword>"+"\n")
            self.jacttokenizer.advance()

        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()==";"):
            self.output_file.write("  "+"<symbol>"+str(self.jacttokenizer.symbol()+"</symbol>")+"\n")
            self.jacttokenizer.advance()
        elif(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
            while (self.jacttokenizer.symbol() == ","):
                self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
                if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                    self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
                    self.jacttokenizer.advance()
            if (self.jacttokenizer.symbol() == ";"):
                self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return
        self.output_file.write(" "+"</varDec>"+"\n")

    def compileParameterList(self):
         self.output_file.write("  "+"<parameterList>"+"\n")
         if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="int" or self.jacttokenizer.keyWord()=="char" or self.jacttokenizer.keyWord()=="boolean"):
             self.output_file.write("   "+"<keyword>"+str(self.jacttokenizer.keyWord()+"</keyword>")+"\n")
             self.jacttokenizer.advance()
         elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
             self.output_file.write("   "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
             self.jacttokenizer.advance()
         else:
             self.output_file.write("   "+"syntax error"+"\n")
             return
         if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
             self.output_file.write("   "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
             self.jacttokenizer.advance()
         else:
             self.output_file.write("   "+"syntax error"+"\n")
             return
         while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
             self.output_file.write("   "+"<symbol>"+str(self.jacttokenizer.symbol()+"</symbol>")+"\n")
             self.jacttokenizer.advance()
             if (self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or self.jacttokenizer.keyWord() == "boolean"):
                 self.output_file.write("   " + "<keyword>" + str(self.jacttokenizer.keyWord() + "</keyword>") + "\n")
                 self.jacttokenizer.advance()
             elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                 self.output_file.write(
                     "   " + "<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>" + "\n")
                 self.jacttokenizer.advance()
             else:
                 self.output_file.write("   " + "syntax error" + "\n")
                 return
             if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                 self.output_file.write(
                     "   " + "<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>" + "\n")
                 self.jacttokenizer.advance()
             else:
                 self.output_file.write("   " + "syntax error" + "\n")
                 return
         self.output_file.write("  "+"</parameterList>"+"\n")

    def compileSubRoutinBody(self):
        self.output_file.write("  "+"<subroutineBody>"+"\n")
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="{"):
            self.output_file.write("   "+"<symbol>"+str(self.jacttokenizer.symbol()+"</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("   "+"syntax error"+"\n")
        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="var"):
               self.compileVarDec()
        while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()):
            self.compilestatments()
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == "}"):
            self.output_file.write("   "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("   "+"syntax error"+"\n")
        self.output_file.write("  "+"</subroutineBody>"+"\n")

    def compileClassVarDec(self):
         self.output_file.write(" "+"<classVarDec>"+"\n")
         if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="static" or self.jacttokenizer.keyWord()=="field"):
             self.output_file.write("  "+"<keyword>" + str(self.jacttokenizer.keyWord()) + "</keyword>"+"\n")
             self.jacttokenizer.advance()

         if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord()=="char" or
             self.jacttokenizer.keyWord()=="boolean"):
             self.output_file.write("  "+"<keyword>" + str(self.jacttokenizer.keyWord()) + "</keyword>"+"\n")
             self.jacttokenizer.advance()

         elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
             self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
             self.jacttokenizer.advance()
         else:
             self.output_file.write("  "+"syntax error"+"\n")
             return
         if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
             self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
             self.jacttokenizer.advance()
         else:
             self.output_file.write("  "+"syntax error"+"\n")
             return
         if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ";"):
             self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
             self.jacttokenizer.advance()
         elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
             while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol() == ","):
                 self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                 self.jacttokenizer.advance()
                 if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
                     self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
                     self.jacttokenizer.advance()
             if(self.jacttokenizer.symbol()==";"):
                 self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol() + "</symbol>")+"\n")
                 self.jacttokenizer.advance()
             else:
                 self.output_file.write("  "+"syntax error"+"\n")
                 return
         else:
             self.output_file.write("  "+"syntax error"+"\n")
             return
         self.output_file.write(" "+"</classVarDec>"+"\n")


    def compileSubroutinDec(self):
        self.output_file.write(" "+"<subroutineDec>"+"\n")
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == 'constructor' or self.jacttokenizer.keyWord() == 'function' or self.jacttokenizer.keyWord() == 'method'):
            self.output_file.write("  "+"<keyword>" + str(self.jacttokenizer.keyWord()) + "</keyword>"+"\n")
            self.jacttokenizer.advance()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == "int" or self.jacttokenizer.keyWord() == "char" or
            self.jacttokenizer.keyWord() == "boolean" or self.jacttokenizer.keyWord()=="void"):
                self.output_file.write("  "+"<keyword>" + str(self.jacttokenizer.keyWord()) + "</keyword>"+"\n")
                self.jacttokenizer.advance()
        elif (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write("  "+"<identifier>" + str(self.jacttokenizer.identifier()) + "</identifier>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="("):
            self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol()) + "</symbol>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="int" or self.jacttokenizer.keyWord()=="char"
             or self.jacttokenizer.keyWord()=="boolean" or self.jacttokenizer.identifier()):
            while(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="int" or self.jacttokenizer.keyWord()=="char"
                 or self.jacttokenizer.keyWord()=="boolean" or self.jacttokenizer.identifier()):
                self.compileParameterList()
        else:
            self.output_file.write("  "+"<parameterList>"+"\n")
            self.output_file.write("  " + "</parameterList>" + "\n")

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()==")"):
            self.output_file.write("  "+"<symbol>" + str(self.jacttokenizer.symbol()) + "</symbol>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("  "+"syntax error"+"\n")
            return
        self.compileSubRoutinBody()

        self.output_file.write(" "+"</subroutineDec>"+"\n")


    def compileClass(self):
        self.output_file.write("<class>" + "\n")
        if(self.jacttokenizer.keyWord()=="class"):
            self.output_file.write(" "+"<keyword>"+"class"+"</keyword>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write("syntax error"+"\n")
            return
            self.jacttokenizer.advance()
        if(self.jacttokenizer.hasMoreLine() and self.jacttokenizer.identifier()):
            self.output_file.write(" "+"<identifier>"+str(self.jacttokenizer.identifier())+"</identifier>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write(" "+"syntax error"+"\n")
            return
        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="{"):
            self.output_file.write(" "+"<symbol>" + str(self.jacttokenizer.symbol()) + "</symbol>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write(" "+"syntax error"+"\n")
            return
        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord()=="static" or self.jacttokenizer.keyWord()=="field"):
            self.compileClassVarDec()

        while (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.keyWord() == 'constructor' or self.jacttokenizer.keyWord() == 'function'
               or self.jacttokenizer.keyWord()=='method'):
               self.compileSubroutinDec()

        if (self.jacttokenizer.hasMoreLine() and self.jacttokenizer.symbol()=="}"):
            self.output_file.write(" "+"<symbol>" + str(self.jacttokenizer.symbol()) + "</symbol>"+"\n")
            self.jacttokenizer.advance()
        else:
            self.output_file.write(" "+"syntax error"+"\n")
            return

        self.output_file.write("</class>")
