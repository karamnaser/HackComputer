class HackSymbolTable:
    def __init__(self):
        self.symbol_table=dict()
        self.symbol_addres_counter = 16


    def addEntry(self,symbol,address):
        self.symbol_table[symbol]=address

    def contain(self,symbol):
        if(symbol in self.symbol_table):
            return True
        else:
            return False

    def getAddress(self,symbol):
        if(self.contain(symbol)):
            return self.symbol_table.get(symbol)

