class HackVmParser:
    def __init__(self,file):
        self.file=file
        self.filetxt=self.file.readlines()
        for i in range(0,len(self.filetxt)):
                self.filetxt[i]= self.filetxt[i].strip()
        self.currentinstruction=0


    def hasMoreLine(self):
        if(len(self.filetxt)>self.currentinstruction):
            return True
        else:
            self.file.close()
            return False

    def advance(self):
        if(self.hasMoreLine()):
            self.currentinstruction+=1

    def commandType(self):
        arthrmetric_logical_comand = ["add", "sub", "neg", "eq", "gt", "lt", "and", "or", "not"]
        if(self.filetxt[self.currentinstruction][0:2]!="//"):
            if(self.filetxt[self.currentinstruction].split(" ")[0] in arthrmetric_logical_comand):
                return "C_ARTHRIMETRIC"
            elif(self.filetxt[self.currentinstruction].find("push")!=-1):
                return "C_PUSH"
            elif(self.filetxt[self.currentinstruction].find("pop")!=-1):
                return "C_POP"
            elif (self.filetxt[self.currentinstruction].find("goto") != -1 and self.filetxt[self.currentinstruction].find("if-goto") == -1):
                return "C_GOTO"
            elif (self.filetxt[self.currentinstruction].find("if-goto") != -1):
                return "C_IF"
            elif (self.filetxt[self.currentinstruction].find("label") != -1):
                return "C_LABEL"
            elif (self.filetxt[self.currentinstruction].find("call") != -1):
                return "C_CALL"
            elif (self.filetxt[self.currentinstruction].find("function") != -1):
                return "C_FUNCTION"
            elif (self.filetxt[self.currentinstruction].find("return") != -1):
                return "C_RETURN"

    def arg1(self):
        comand=self.filetxt[self.currentinstruction].split(" ")
        if(self.commandType()=="C_RETURN"):
            return
        elif(len(comand)==0):
            return

        elif(self.commandType()=="C_ARTHRIMETRIC"):
            return comand[0]

        elif(self.commandType()=="C_PUSH" or self.commandType()=="C_POP"):
            return comand[1]

    def arg2(self):
        comand=self.filetxt[self.currentinstruction].split(" ")
        if(len(comand)==0):
            return

        elif(self.commandType()=="C_PUSH" or self.commandType()=="C_POP"):
            return int(comand[2])
        elif(self.commandType()=="C_LABEL" or self.commandType()=="C_IF" or self.commandType()=="C_GOTO"):
            return comand[1]
        elif(self.commandType()=="C_FUNCTION" or self.commandType()=="C_CALL"):
            return comand[1],comand[2]

