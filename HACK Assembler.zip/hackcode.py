class HackCode:
   def dest(self,dist_s):
       destOut=""
       if dist_s == None:
           destOut = "000"
       elif dist_s=="M":
           destOut = "001"
       elif dist_s=="D":
            destOut = "010"
       elif dist_s=="MD":
            destOut = "011"
       elif dist_s=="A":
            destOut = "100"
       elif dist_s=="AM":
            destOut = "101"
       elif dist_s=="AD":
            destOut = "110"
       elif dist_s=="AMD":
            destOut = "111"

       return destOut

   def comp(self,compIn):
       compout=""
       if compIn == None:
          return
       elif compIn=="0":
             compout = "101010"
       elif compIn=="1":
            compout = "111111"
       elif compIn=="-1":
            compout = "111010"
       elif compIn=="D":
            compout = "001100"
       elif compIn=="A":
            compout = "110000"
       elif compIn=="!D":
            compout = "001101"
       elif compIn=="!A":
            compout = "110001"
       elif compIn=="-D":
            compout = "001111"
       elif compIn=="-A":
            compout = "110011"
       elif compIn=="D+1":
            compout = "011111"
       elif compIn=="A+1":
            compout = "110111"
       elif compIn=="D-1":
            compout = "001110"
       elif compIn=="A-1":
            compout = "110010"
       elif compIn=="D+A":
            compout = "000010"
       elif compIn=="D-A":
            compout = "010011"
       elif compIn=="A-D":
            compout = "000111"
       elif compIn=="D&A":
            compout = "000000"
       elif compIn=="D|A":
            compout = "010101"
       elif compIn=="M":
            compout = "110000"
       elif compIn=="!M":
            compout = "110001"
       elif compIn=="-M":
            compout = "110011"
       elif compIn=="M+1":
            compout = "110111"
       elif compIn=="M-1":
            compout = "110010"
       elif compIn=="D+M":
            compout = "000010"
       elif compIn=="D-M":
            compout = "010011"
       elif compIn=="M-D":
            compout = "000111"
       elif compIn=="D&M":
            compout = "000000"
       elif compIn=="D|M":
            compout = "010101"
       return compout

   def jump(self,jumpin):
       jumpout=""
       if jumpin == None:
           jumpout = "000"
       elif jumpin=="JGT":
           jumpout = "001"
       elif jumpin=="JEQ":
           jumpout = "010"
       elif jumpin=="JGE":
           jumpout = "011"
       elif jumpin=="JLT":
           jumpout = "100"
       elif jumpin=="JNE":
           jumpout = "101"
       elif jumpin=="JLE":
           jumpout = "110"
       elif jumpin=="JMP":
           jumpout = "111"

       return jumpout
