import sys
import os.path
import pathlib
from hackvmparser import *
from hackvmcodewriter import *

def findfilepath():
    if (sys.argv[1].find("\\")):
        sys.argv[1] = sys.argv[1].split("\\")[-1]

    for r, d, f in os.walk("C:\\"):
        for files in f:
            if files.capitalize() == sys.argv[1].capitalize():
                return os.path.join(r, files)

def getDirName():
    if (sys.argv[1].find("\\")):
        sys.argv[1] = sys.argv[1].split("\\")[-1]
    for r, d, f in os.walk("C:\\"):
        for directory in d:
            if (directory.capitalize() == sys.argv[1].capitalize()):
                dir = os.path.join(r, directory)
                return dir
        else:
            continue


def checkIfFileOrDir():
    if(sys.argv[1].find(".vm")==-1):
        path=(getDirName(),"isdire")
    else:
        path=(findfilepath(),"isfile")
    return path

def parseAndGenrateCode(parser,codegeneratore):
    while (parser.hasMoreLine()):
        comand_type = parser.commandType()
        arg = parser.arg1()
        arg2 = parser.arg2()
        if(arg2):
            if(type(arg2)!=int):
                if(str(arg2[0]).capitalize()=="sys.init".capitalize()):
                    codegeneratore.writeBootsrapCode()
        if (comand_type == "C_ARTHRIMETRIC"):
            codegeneratore.writeArithmetic(arg)
        if (comand_type == "C_LABEL"):
            codegeneratore.writelable(arg2)
        elif (comand_type == "C_IF"):
            codegeneratore.writeIF(arg2)
        elif (comand_type == "C_GOTO"):
            codegeneratore.writeGoTo(arg2)
        elif (comand_type == "C_FUNCTION"):
            codegeneratore.setFileName(arg2[0])
            codegeneratore.writeFunction(arg2[0], arg2[1])
        elif (comand_type == "C_CALL"):
            codegeneratore.writeCall(arg2[0], arg2[1])
        elif (comand_type == "C_RETURN"):
            codegeneratore.writereturn()
        codegeneratore.writePushPop(comand_type, arg, arg2)
        parser.advance()
    codegeneratore.close()

def main():
    filename = checkIfFileOrDir()
    counter=0
    if(filename[1]=="isdire"):
        for r,d,f in os.walk(filename[0]):
            fileslist=f
        writable_asm_file=open(os.path.join(filename[0],sys.argv[1].split(".")[0]+".asm"),"w+")
        sysfileindex=fileslist.index("Sys.vm")
        sysfile=fileslist.pop(sysfileindex)
        fileslist.insert(0,sysfile)
        for file in fileslist:
            if (file.find(".vm") != -1):
                readble_vm_file = open(os.path.join(filename[0],file),"r")
                vmparser = HackVmParser(readble_vm_file)
                vmcodewriter = HackVmCodeWriter(writable_asm_file)
                vmcodewriter.returnaddres_counter=counter
                parseAndGenrateCode(vmparser, vmcodewriter)
                writable_asm_file.write("\n")
                counter=vmcodewriter.returnaddres_counter
                readble_vm_file.close()
    else:
        readble_vm_file = open(filename[0], "r")
        writable_asm_file = open(filename[0].replace(".vm",".asm"),"w+")
        vmparser = HackVmParser(readble_vm_file)
        vmcodewriter = HackVmCodeWriter(writable_asm_file)
        parseAndGenrateCode(vmparser,vmcodewriter)
        readble_vm_file.close()



main()


